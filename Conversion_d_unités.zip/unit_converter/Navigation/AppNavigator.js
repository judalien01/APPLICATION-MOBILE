import React from 'react';
import { createDrawerNavigator } from '@react-navigation/drawer';
import { createStackNavigator } from '@react-navigation/stack';
import HomeScreen from '../screens/HomeScreen';
import LengthScreen from '../screens/LengthScreen';
import MassScreen from '../screens/MassScreen';
import TemperatureScreen from '../screens/TemperatureScreen';
import TimeScreen from '../screens/TimeScreen';
import SettingsScreen from '../screens/SettingsScreen';
import ShareScreen from '../screens/ShareScreen';
import FeedbackScreen from '../screens/FeedbackScreen';
import QuitScreen from '../screens/QuitScreen';

const Drawer = createDrawerNavigator();
const Stack = createStackNavigator();

function MainStackNavigator() {
  return (
    <Stack.Navigator>
      <Stack.Screen name="Home" component={HomeScreen} options={{ title: 'Accueil' }} />
      <Stack.Screen name="Length" component={LengthScreen} />
      <Stack.Screen name="Mass" component={MassScreen} />
      <Stack.Screen name="Temperature" component={TemperatureScreen} />
      <Stack.Screen name="Time" component={TimeScreen} />
    </Stack.Navigator>
  );
}

export default function AppNavigator() {
  return (
    <Drawer.Navigator initialRouteName="Home">
      <Drawer.Screen name="Home" component={MainStackNavigator} options={{ title: 'Menu' }} />
      <Drawer.Screen name="Settings" component={SettingsScreen} />
      <Drawer.Screen name="Share" component={ShareScreen} />
      <Drawer.Screen name="Feedback" component={FeedbackScreen} />
      <Drawer.Screen name="Quit" component={QuitScreen} />
    </Drawer.Navigator>
  );
}
