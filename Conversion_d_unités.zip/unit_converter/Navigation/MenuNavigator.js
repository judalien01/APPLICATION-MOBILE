import React from 'react';
import { createDrawerNavigator } from '@react-navigation/drawer';
import { NavigationContainer } from '@react-navigation/native';
import HomeScreen from '../screens/HomeScreen';
import SettingsScreen from '../screens/SettingsScreen';
import ShareScreen from '../screens/ShareScreen';
import FeedbackScreen from '../screens/FeedbackScreen';
import QuitScreen from '../screens/QuitScreen';

const Drawer = createDrawerNavigator();

export default function MenuNavigator() {
  return (
    <NavigationContainer>
      <Drawer.Navigator initialRouteName="Menu">
        <Drawer.Screen name="Menu" component={HomeScreen} />
        <Drawer.Screen name="Settings" component={SettingsScreen} />
        <Drawer.Screen name="Share" component={ShareScreen} />
        <Drawer.Screen name="Feedback" component={FeedbackScreen} />
        <Drawer.Screen name="Quit" component={QuitScreen} />
      </Drawer.Navigator>
    </NavigationContainer>
  );
}
