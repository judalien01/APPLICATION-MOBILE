import React, { useState } from 'react';
import { View, Text, TextInput, StyleSheet, Button } from 'react-native';
import { convertTime } from '../Utils/conversionUtils';

const TimeConverter = () => {
  const [value, setValue] = useState('');
  const [fromUnit, setFromUnit] = useState('');
  const [toUnit, setToUnit] = useState('');
  const [result, setResult] = useState('');

  const handleConvert = () => {
    const convertedValue = convertTime(parseFloat(value), fromUnit, toUnit);
    setResult(convertedValue.toFixed(2));
  };

  return (
    <View style={styles.container}>
      <Text style={styles.text}>Conversion de Temps</Text>
      <TextInput
        style={styles.input}
        keyboardType="numeric"
        placeholder="Entrer la valeur"
        value={value}
        onChangeText={setValue}
      />
      <TextInput
        style={styles.input}
        placeholder="Unité de départ (ex: hours)"
        value={fromUnit}
        onChangeText={setFromUnit}
      />
      <TextInput
        style={styles.input}
        placeholder="Unité de destination (ex: minutes)"
        value={toUnit}
        onChangeText={setToUnit}
      />
      <Button title="Convertir" onPress={handleConvert} />
      {result !== '' && <Text style={styles.result}>Résultat : {result}</Text>}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
  },
  text: {
    fontSize: 20,
    marginBottom: 16,
  },
  input: {
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    marginBottom: 16,
    paddingHorizontal: 8,
    width: '80%',
  },
  result: {
    marginTop: 16,
    fontSize: 18,
    color: 'green',
  },
});

export default TimeConverter;
