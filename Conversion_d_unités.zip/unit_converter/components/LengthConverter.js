import React, { useState } from 'react';
import { View, Text, TextInput, StyleSheet, Button } from 'react-native';
import { convertLength } from '../Utils/conversionUtils';

const LengthConverter = () => {
  const [value, setValue] = useState('');
  const [fromUnit, setFromUnit] = useState('meters');
  const [toUnit, setToUnit] = useState('kilometers');
  const [result, setResult] = useState('');

  const handleConvert = () => {
    const convertedValue = convertLength(parseFloat(value), fromUnit, toUnit);
    setResult(convertedValue.toFixed(2));
  };

  return (
    <View style={styles.container}>
      <Text style={styles.text}>Conversion de Longueur</Text>
      <TextInput
        style={styles.input}
        keyboardType="numeric"
        placeholder="Entrer la valeur"
        value={value}
        onChangeText={setValue}
      />
      <TextInput
        style={styles.input}
        placeholder="From Unit (e.g., meters)"
        value={fromUnit}
        onChangeText={(text) => {
          console.log('From Unit:', text);
          setFromUnit(text);
        }}
      />
      <TextInput
        style={styles.input}
        placeholder="To Unit (e.g., kilometers)"
        value={toUnit}
        onChangeText={(text) => {
          console.log('To Unit:', text);
          setToUnit(text);
        }}
      />
      <Button title="Convertir" onPress={handleConvert} />
      {result !== '' && <Text style={styles.result}>Résultat : {result}</Text>}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
  },
  text: {
    fontSize: 20,
    marginBottom: 16,
  },
  input: {
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    marginBottom: 16,
    paddingHorizontal: 8,
    width: '80%',
  },
  result: {
    marginTop: 16,
    fontSize: 18,
    color: 'green',
  },
});

export default LengthConverter;
