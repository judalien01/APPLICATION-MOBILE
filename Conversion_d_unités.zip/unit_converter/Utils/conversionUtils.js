// conversionUtils.js

export const convertLength = (value, fromUnit, toUnit) => {
    const conversionRates = {
      'meters-kilometers': 0.001,
      'kilometers-meters': 1000,
      'meters-centimeters': 100,
      'centimeters-meters': 0.01,
      'kilometers-miles': 0.621371,
      'miles-kilometers': 1.60934,
    };
    const key = `${fromUnit}-${toUnit}`;
    return value * (conversionRates[key] || 1);
  };
  
  export const convertMass = (value, fromUnit, toUnit) => {
    const conversionRates = {
      'kilograms-grams': 1000,
      'grams-kilograms': 0.001,
      'kilograms-pounds': 2.20462,
      'pounds-kilograms': 0.453592,
    };
    const key = `${fromUnit}-${toUnit}`;
    return value * (conversionRates[key] || 1);
  };
  
  export const convertTemperature = (value, fromUnit, toUnit) => {
    if (fromUnit === 'Celsius' && toUnit === 'Fahrenheit') {
      return (value * 9/5) + 32;
    } else if (fromUnit === 'Fahrenheit' && toUnit === 'Celsius') {
      return (value - 32) * 5/9;
    } else if (fromUnit === 'Celsius' && toUnit === 'Kelvin') {
      return value + 273.15;
    } else if (fromUnit === 'Kelvin' && toUnit === 'Celsius') {
      return value - 273.15;
    } else if (fromUnit === 'Fahrenheit' && toUnit === 'Kelvin') {
      return (value - 32) * 5/9 + 273.15;
    } else if (fromUnit === 'Kelvin' && toUnit === 'Fahrenheit') {
      return (value - 273.15) * 9/5 + 32;
    }
    return value;
  };
  
  export const convertTime = (value, fromUnit, toUnit) => {
    const conversionRates = {
      'hours-minutes': 60,
      'minutes-hours': 1/60,
      'hours-seconds': 3600,
      'seconds-hours': 1/3600,
      'minutes-seconds': 60,
      'seconds-minutes': 1/60,
    };
    const key = `${fromUnit}-${toUnit}`;
    return value * (conversionRates[key] || 1);
  };
  