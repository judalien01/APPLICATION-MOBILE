import React from 'react';
import { View, StyleSheet } from 'react-native';
import TimeConverter from '../components/TimeConverter';

const TimeScreen = () => {
  return (
    <View style={styles.container}>
      <TimeConverter />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f5f5f5',
  },
});

export default TimeScreen;
