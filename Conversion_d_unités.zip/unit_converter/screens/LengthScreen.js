import React from 'react';
import { View, StyleSheet } from 'react-native';
import LengthConverter from '../components/LengthConverter';

const LengthScreen = () => {
  return (
    <View style={styles.container}>
      <LengthConverter />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f5f5f5',
  },
});

export default LengthScreen;
