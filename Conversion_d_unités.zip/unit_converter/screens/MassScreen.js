import React from 'react';
import { View, StyleSheet } from 'react-native';
import MassConverter from '../components/MassConverter';

const MassScreen = () => {
  return (
    <View style={styles.container}>
      <MassConverter />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f5f5f5',
  },
});

export default MassScreen;
