import React from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';

const SettingsScreen = ({ navigation }) => {
  return (
    <View style={styles.container}>
      <Text style={styles.text}>Paramètres</Text>
      <Button title="Thèmes" onPress={() => { /* Ajouter la logique de changement de thème */ }} />
      <Button title="Paysage/Portrait" onPress={() => { /* Ajouter la logique de changement d'orientation */ }} />
      <Button title="Nombre Décimal" onPress={() => { /* Ajouter la logique de réglage du nombre de décimales */ }} />
      <Button title="Langue" onPress={() => { /* Ajouter la logique de changement de langue */ }} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
  },
  text: {
    fontSize: 20,
    marginBottom: 16,
  },
});

export default SettingsScreen;
