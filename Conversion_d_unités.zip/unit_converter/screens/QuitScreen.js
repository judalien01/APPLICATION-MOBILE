import React from 'react';
import { View, Text, StyleSheet, Button } from 'react-native';

const QuitScreen = ({ navigation }) => {
  const handleQuit = () => {
    // Implémenter la logique de quitter l'application
  };

  return (
    <View style={styles.container}>
      <Text>Quitter l'application</Text>
      <Button title="Quitter" onPress={handleQuit} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f5f5f5',
  },
});

export default QuitScreen;
